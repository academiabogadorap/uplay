HTTP/1.1 302 FOUND
Server: Werkzeug/3.1.3 Python/3.11.6
Date: Fri, 31 Oct 2025 15:43:52 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 193
Location: /mi
Vary: Cookie
Set-Cookie: session=.eJwNzEEKgzAQRuGryL8OkoxYNMteo0iITqZNbRMwthvx7mb1wVu8A04-vrxCgX0caPYK8gqFewzpH1LkrBrP35haTOeksJRN3J7XkGDBmrgfh1nTQlI1_iadJ9IydGzMyLWK7uf6e_-envPmIsMSnRclfSV2.aQTZOA.vyFm6Tdg7zjn5jkDZEKtb4Soz5c; HttpOnly; Path=/
Connection: close

