HTTP/1.1 302 FOUND
Server: Werkzeug/3.1.3 Python/3.11.6
Date: Fri, 31 Oct 2025 16:38:53 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 229
Location: /olvide-pin/confirmar
Vary: Cookie
Set-Cookie: session=.eJwVjbEOgjAUAH_l5U2aENOWYIDVycW4KyGl71XRQk0LJIbw79bpcrfciq11Oj45Yn1bEaYE5BB8wAxPfvg4nu6zECyBB927DMxfbU79w8MX2ME48-Lher7AjnyEhQ3H_QGbrcnQxGDbyb95xBpJKCqqshPKKJso9dHmWilhy5ykrChVK4ounV_zQ5MPbU9YK7X9AG5vNBg.aQTmHQ.t6FSyY_vEiNFYch20tUbHnXpVA0; HttpOnly; Path=/
Connection: close

