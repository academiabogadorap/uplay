HTTP/1.1 302 FOUND
Server: Werkzeug/3.1.3 Python/3.11.6
Date: Fri, 31 Oct 2025 15:37:34 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 199
Location: /login
Vary: Cookie
Set-Cookie: session=.eJxdTUsKwjAQvcow61KSFMV6A9eCGxUZkwkGa1ImUYTSuxt1I64e7z_hyQ-UL5xxvZ8QSgVkkSTY4JZzONyV8l0Efo5ByBEk8Elu94EkJAjx8Q6wHoJLLezS8OU9UPUKx0LS4nFu_qc3MdjwrUL-uRlJCMhadvwpHhu0WfyppCtHXKNTxi361VkZa3xFTUvfkTHKrzqnde-q6tXijPMLHFFGew.aQTXvg.3bTyN8KYYovVvv-P-SL08quiBFw; HttpOnly; Path=/
Connection: close

