HTTP/1.1 302 FOUND
Server: Werkzeug/3.1.3 Python/3.11.6
Date: Fri, 31 Oct 2025 15:52:29 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 189
Location: /
Vary: Cookie
Set-Cookie: session=.eJwNyEEKgzAQBdCryF-LTCZY1Gu4tCJjJkOLRSGxK_HuZvXgXVjsJ_kTM4bpQnUWcGyoMcb8ff-JzO9ViCmJSoP5nmuEnGw5jy3uGKDE2vbdShzYik5e5oWZrPPqXK9ljdoV9wMnJSC2.aQTbPQ.ZNE9XkrpQYAY8l6YZrfbnTHb_bw; HttpOnly; Path=/
Connection: close

