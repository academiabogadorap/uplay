HTTP/1.1 302 FOUND
Server: Werkzeug/3.1.3 Python/3.11.6
Date: Fri, 31 Oct 2025 16:38:40 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 209
Location: /olvide-pin
Vary: Cookie
Set-Cookie: session=.eJwlzkEKgzAQheGrDLOWEiMW9RpdtiIxM2NTbQKJSkG8e7Vd_Y9v9TbsZDLpyQmb-4YwH8EwYoY3BzyBDTFyAP64NDOwPy2d-20y-MnqzDskWDzYx6KUFOSGAMSwcnTirLHu7_6C7d5maFOUbg4je2yQlKayrnqlrZajublKYbRWUhWU5zUdKqrsj0OvZTAUYucIG633L4ncPBE.aQTmEA.OCtSYaK_F1MClmWygeQeQK58KV4; HttpOnly; Path=/
Connection: close

