HTTP/1.1 302 FOUND
Server: Werkzeug/3.1.3 Python/3.11.6
Date: Fri, 31 Oct 2025 15:47:36 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 223
Location: /admin/solicitudes
Vary: Cookie
Set-Cookie: session=.eJwljbEOgjAUAH-leTMx7asY6Gaig67iZEhT2j6sIDWAgyH8uzVOl7vlFtDUm-nuJ1C3BdicALGDDM7v1rg4Mjv6RPZhQ5wDBfuTV-r-aUKvWHW8VGx_PZwqhhxzwaXQAoXk2w3Ua52BnUbSc-z8AAocR5eXRcPRIiUKsyNpEDkV0glRulSJ5036P_5_HRwoxPULi8YzUw.aQTaGA.16CArY5rhWpv7wdOgHErjlyUNhY; HttpOnly; Path=/
Connection: close

