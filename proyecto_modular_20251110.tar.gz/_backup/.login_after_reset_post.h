HTTP/1.1 400 BAD REQUEST
Server: Werkzeug/3.1.3 Python/3.11.6
Date: Fri, 31 Oct 2025 16:38:58 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 241
Location: http://127.0.0.1:5000/login
Vary: Cookie
Set-Cookie: session=.eJwljsEKwjAQRH8l7LmUJKXS9jcEL1rKtslqNCaySUUo_Xcjnh4zbw6zwUQe080mGM4biFwAljkyVHC0yV1WKakJwn5ejtGgiIIiP1eP7KJw4f0bWOWdibU4Rf_PvcDisg0ZuYZxHytYEtOU48MGGMBIbdq-m6VeNBUqPFCDWkvqGqNUb0pLsp3Lift6RRN5cgYGrfcvhHk5PQ.aQTmIg.bcsn3UlHiTvPCrlnOlpP5fNr3Yk; HttpOnly; Path=/
Connection: close

